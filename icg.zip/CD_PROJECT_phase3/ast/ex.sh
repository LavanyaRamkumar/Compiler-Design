cd ast	
#printf "\n--------------- AST --------------- AST ---------------------- AST ---------------\n"
#printf "dummy ast\n"
#yacc -d grammar.y
#lex grammar.l
#gcc y.tab.c lex.yy.c -ll -ly
#./a.out < ../IO/ip1.c 
cd ../symtab
