#include <stdio.h>
int main()
{
	int a,b,c;
	while(a>b)
	{
		a=100;
		while(b>a)
		{
			a++;
			if(a>b){
				a++;
			}
			else{
			++b;
			}
			if(a!=b){
				a=c;
			}
		}
		b=100;
	}
	c=100;
}