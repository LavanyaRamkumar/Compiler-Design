#define c 2
int a;
#include<stdio.h>
#include"sdv.h"
int b;
int main(){
int a;
-a++;
}



